#! /usr/bin/env python

import psycopg2


Database_Name = "news"

# 1. Tells the most popular three articles of all time
query1 = "select title,views from count_view limit 3"

# 2. tells the most popular article authors of all time
query2 = """select authors.name,sum(count_view.views) as views from
count_view,authors where authors.id = count_view.author
group by authors.name order by views desc"""

# 3. On which days did more than 1% of requests lead to errors?
query3 = "select * from error_views where \"percentage error\" > 1"

# store results
query_1result = dict()
query_1result['title'] = "\n1. The three most popular articles of all time are:\n"

query_2result = dict()
query_2result['title'] = """\n2. The most popular article authors of
all time are:\n"""

query_3result = dict()
query_3result['title'] = """\n3. Days with more than 1 % of request that
lead to an error:\n"""


# returns query result
def get_query_result(query):
    db = psycopg2.connect(database=Database_Name)
    c = db.cursor()
    c.execute(query)
    results = c.fetchall()
    db.close()
    return results


def print_query_results(query_result):
    print (query_result['title'])
    for result in query_result['results']:
        print ('\t' + str(result[0]) + ' -> ' + str(result[1]) + ' views')


def print_error_query_results(query_result):
    print (query_result['title'])
    for result in query_result['results']:
        print ('\t' + str(result[0]) + ' -> ' + str(result[1]) + ' %')


# stores query result
query_1result['results'] = get_query_result(query1)
query_2result['results'] = get_query_result(query2)
query_3result['results'] = get_query_result(query3)

# print formatted output
print_query_results(query_1result)
print_query_results(query_2result)
print_error_query_results(query_3result)
