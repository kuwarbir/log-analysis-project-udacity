Project Overview
In this project, you'll work with data that could have come from a real-world web application, with fields representing information that a web server would record, such as HTTP status codes and URL paths. The web server and the reporting tool both connect to the same database, allowing information to flow from the web server into the report.

How to Run?
PreRequisites:
Python3
Vagrant
VirtualBox
Setup Project:
Install Vagrant and VirtualBox
Download or Clone fullstack-nanodegree-vm repository.
Download the data from here.
Unzip this file after downloading it. The file inside is called newsdata.sql 
Copy the newsdata.sql file and content of this current repository, by either downloading or cloning it from Here
Launching the Virtual Machine:
Launch the Vagrant VM inside Vagrant sub-directory in the downloaded fullstack-nanodegree-vm repository using command:
  $ vagrant up
Then Log into this using command:
  $ vagrant ssh
Change directory to /vagrant and look around with ls.
Setting up the database and Creating Views:
Load the data in local database using the command:
  psql -d news -f newsdata.sql
The database includes three tables:

The authors table includes information about the authors of articles.
The articles table includes the articles themselves.
The log table includes one entry for each time a user has accessed the site.
Use psql -d news to connect to database .
then create the required views :-
create view count_view as select title,author,count(*) as views from articles,log where log.path
like concat('%',articles.slug) group by articles.title,articles.author order by views desc;
create view error_views as select date(time),round(100.0*sum(case log.status when '200 OK' then 0else 1 end)/count(log.status),2) as
"percentage error" from log group by date(time) order by "percentage error" desc;           

To Run the final queries in the python file use the command python newsdata.p